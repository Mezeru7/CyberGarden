from Ulog import ULog

if __name__ == "__main__":
    ulog = ULog("./test.ulg", None, False)
    data = ulog.data_list
    header = []
    result = {}
    data.sort(key=lambda x: x.name)
    maxlen = 0
    for d in data:
        print(d.data)
        print("-----")
        names = [f.field_name for f in d.field_data]
        names.remove('timestamp')
        names.insert(0, 'timestamp')
        for head in names:
            if (d.name + '.' + head) not in header: header.append(d.name + '.' + head)
        if len(d.data['timestamp']) > maxlen:
            maxlen = len(d.data['timestamp'])

    for d in data:
        d_keys = [f.field_name for f in d.field_data]
        d_keys.remove('timestamp')
        d_keys.insert(0, 'timestamp')
        for key in d_keys:
            result[d.name + '.' + key] = d.data[key]